import pandas as pd
from sklearn.svm import SVR
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib.pyplot as plt

# Load the dataset
file_path = 'Student_academicperformance2.csv'
data = pd.read_csv(file_path)

# Drop non-informative columns (Roll No., Name)
data_cleaned = data.drop(columns=['Roll No.', 'Name'])

# Encode categorical variables using one-hot encoding
data_encoded = pd.get_dummies(data_cleaned, drop_first=True)

# Separate features (X) and target (y)
X = data_encoded.drop(columns=['CGPA'])
y = data_encoded['CGPA']  # CGPA is the target variable

# Handle any missing values by filling with the mean of each column
X = X.fillna(0)

# Initialize the SVR model
model = SVR()

# Split the data into training and testing sets (80% training, 20% testing)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train the SVR model on the data
model.fit(X_train, y_train)

# Predict on the test set
y_pred = model.predict(X_test)

# Evaluate the model
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

accuracy = r2  # R² represents the proportion of variance explained by the model

# Display model evaluation metrics
print("Mean Squared Error (MSE):", mse)
print("R-squared (R²):", r2)
print("Accuracy (R²):", accuracy)

# Plot predicted vs. actual CGPA
plt.figure(figsize=(12, 6))

# Scatter plot of predicted vs. actual values
plt.subplot(1, 2, 1)
plt.scatter(y_test, y_pred, alpha=0.7)
plt.xlabel('Actual CGPA')
plt.ylabel('Predicted CGPA')
plt.title('Predicted vs Actual CGPA')

# Residual plot
residuals = y_test - y_pred
plt.subplot(1, 2, 2)
plt.scatter(y_pred, residuals, alpha=0.7)
plt.axhline(y=0, color='r', linestyle='--')
plt.xlabel('Predicted CGPA')
plt.ylabel('Residuals')
plt.title('Residual Plot')

plt.tight_layout()
plt.show()
