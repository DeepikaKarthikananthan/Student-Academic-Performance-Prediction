import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.metrics import precision_score
import matplotlib.pyplot as plt
import numpy as np

file_path = 'Student_academicperformance2.csv'
data = pd.read_csv(file_path)

# Prepare a dictionary to store precisions
precision_dict = {'Sem 1': [], 'Sem 2': [], 'Sem 3': [], 'Sem 4': [], 'Sem 5': [], 'Sem 6': []}

# Splitting data into features and target for each semester
semesters = ['Sem 1', 'Sem 2', 'Sem 3', 'Sem 4', 'Sem 5', 'Sem 6']
target = 'CGPA'

for sem in semesters:
    # Prepare the dataset
    X = data[[sem]].values
    y = data[target].apply(lambda x: 1 if x >= 7 else 0).values  # Consider CGPA >= 7 as 1, else 0 (binary classification)
    
    # Split the dataset
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

    # Random Forest
    rf = RandomForestClassifier(random_state=42)
    rf.fit(X_train, y_train)
    y_pred_rf = rf.predict(X_test)
    precision_dict[sem].append(precision_score(y_test, y_pred_rf))
    
    # Decision Tree
    dt = DecisionTreeClassifier(random_state=42)
    dt.fit(X_train, y_train)
    y_pred_dt = dt.predict(X_test)
    precision_dict[sem].append(precision_score(y_test, y_pred_dt))
    
    # ID3 - using DecisionTreeClassifier with 'entropy' criterion
    id3 = DecisionTreeClassifier(criterion='entropy', random_state=42)
    id3.fit(X_train, y_train)
    y_pred_id3 = id3.predict(X_test)
    precision_dict[sem].append(precision_score(y_test, y_pred_id3))
    
    # SVC
    svc = SVC(random_state=42)
    svc.fit(X_train, y_train)
    y_pred_svc = svc.predict(X_test)
    precision_dict[sem].append(precision_score(y_test, y_pred_svc))

# Plotting the precision graph
N = len(semesters)
ind = np.arange(N)
width = 0.2

fig, ax = plt.subplots(figsize=(12, 6))
ax.bar(ind - 1.5*width, [precision_dict[sem][0] for sem in semesters], width, label='Random Forest')
ax.bar(ind - 0.5*width, [precision_dict[sem][1] for sem in semesters], width, label='Decision Tree')
#ax.bar(ind + 0.5*width, [precision_dict[sem][2] for sem in semesters], width, label='ID3 Algorithm')
ax.bar(ind + 0.5*width, [precision_dict[sem][3] for sem in semesters], width, label='SVC')

ax.set_xlabel('Semesters')
ax.set_ylabel('Precision')
ax.set_title('Algorithm Precision for Each Semester')
ax.set_xticks(ind)
ax.set_xticklabels(semesters)
ax.set_yticks(np.arange(0.1, 1.1, 0.1))  # Setting the y-axis ticks from 0.1 to 1.0
ax.legend(loc='best')

plt.show()
