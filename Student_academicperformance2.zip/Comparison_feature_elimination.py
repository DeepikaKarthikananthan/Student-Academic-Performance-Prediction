"""import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.feature_selection import RFE
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib.pyplot as plt

# Load the dataset
file_path = 'Student_academicperformance2.csv'
data = pd.read_csv(file_path)

# Clean the data
data_cleaned = data.drop(columns=['Roll No.', 'Name'])

# Encode categorical variables using one-hot encoding
data_encoded = pd.get_dummies(data_cleaned, drop_first=True)

# Separate features (X) and target (y)
X = data_encoded.drop(columns=['CGPA'])
y = data_encoded['CGPA']  

# Fill missing values with 0
X = X.fillna(0)

# Define a function to evaluate model performance
def evaluate_model(X_train, X_test, y_train, y_test):
    model = LinearRegression()
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    mse = mean_squared_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)
    return mse, r2

# No feature elimination
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.8, random_state=42)
mse_no_elim, r2_no_elim = evaluate_model(X_train, X_test, y_train, y_test)

# RFE feature elimination
rfe = RFE(estimator=LinearRegression(), n_features_to_select=6)
rfe = rfe.fit(X, y)
X_selected_rfe = X.loc[:, rfe.support_]
X_train_rfe, X_test_rfe, y_train_rfe, y_test_rfe = train_test_split(X_selected_rfe, y, test_size=0.8, random_state=42)
mse_rfe, r2_rfe = evaluate_model(X_train_rfe, X_test_rfe, y_train_rfe, y_test_rfe)

# LDA feature elimination
lda = LDA(n_components=2)
X_lda = lda.fit_transform(X, pd.cut(y, bins=3, labels=['Low', 'Medium', 'High']))
X_train_lda, X_test_lda, y_train_lda, y_test_lda = train_test_split(X_lda, y, test_size=0.8, random_state=42)
mse_lda, r2_lda = evaluate_model(X_train_lda, X_test_lda, y_train_lda, y_test_lda)

# PCA feature reduction
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X)
X_train_pca, X_test_pca, y_train_pca, y_test_pca = train_test_split(X_pca, y, test_size=0.8, random_state=42)
mse_pca, r2_pca = evaluate_model(X_train_pca, X_test_pca, y_train_pca, y_test_pca)

# Plot comparison bar chart
plt.figure(figsize=(14, 7))

# Bar chart for MSE
plt.subplot(1, 2, 1)
methods = ['No Elimination', 'RFE', 'LDA', 'PCA']
mse_values = [mse_no_elim, mse_rfe, mse_lda, mse_pca]
plt.bar(methods, mse_values, color=['blue', 'orange', 'green', 'red'])
plt.xlabel('Feature Selection Method')
plt.ylabel('Mean Squared Error (MSE)')
plt.title('MSE Comparison')

# Bar chart for R²
plt.subplot(1, 2, 2)
r2_values = [r2_no_elim, r2_rfe, r2_lda, r2_pca]
plt.bar(methods, r2_values, color=['blue', 'orange', 'green', 'red'])
plt.xlabel('Feature Selection Method')
plt.ylabel('R-squared (R²)')
plt.title('R² Comparison')

plt.tight_layout()
plt.show()"""

import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.feature_selection import RFE
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib.pyplot as plt
import timeit

# Load the dataset
file_path = 'Student_academicperformance2.csv'
data = pd.read_csv(file_path)

# Clean the data
data_cleaned = data.drop(columns=['Roll No.', 'Name'])

# Encode categorical variables using one-hot encoding
data_encoded = pd.get_dummies(data_cleaned, drop_first=True)

# Separate features (X) and target (y)
X = data_encoded.drop(columns=['CGPA'])
y = data_encoded['CGPA']  

# Fill missing values with 0
X = X.fillna(0)

# Define a function to evaluate model performance
def evaluate_model(X_train, X_test, y_train, y_test):
    model = LinearRegression()
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    mse = mean_squared_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)
    return mse, r2

# No feature elimination
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.8, random_state=42)
mse_no_elim, r2_no_elim = evaluate_model(X_train, X_test, y_train, y_test)

# RFE feature elimination
rfe = RFE(estimator=LinearRegression(), n_features_to_select=6)
rfe = rfe.fit(X, y)
X_selected_rfe = X.loc[:, rfe.support_]
X_train_rfe, X_test_rfe, y_train_rfe, y_test_rfe = train_test_split(X_selected_rfe, y, test_size=0.8, random_state=42)
mse_rfe, r2_rfe = evaluate_model(X_train_rfe, X_test_rfe, y_train_rfe, y_test_rfe)

# LDA feature elimination (convert y to categorical for LDA)
y_categorical = pd.cut(y, bins=3, labels=['Low', 'Medium', 'High'])
lda = LDA(n_components=2)
X_lda = lda.fit_transform(X, y_categorical)
X_train_lda, X_test_lda, y_train_lda, y_test_lda = train_test_split(X_lda, y, test_size=0.8, random_state=42)
mse_lda, r2_lda = evaluate_model(X_train_lda, X_test_lda, y_train_lda, y_test_lda)

# PCA feature reduction
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X)
X_train_pca, X_test_pca, y_train_pca, y_test_pca = train_test_split(X_pca, y, test_size=0.8, random_state=42)
mse_pca, r2_pca = evaluate_model(X_train_pca, X_test_pca, y_train_pca, y_test_pca)

# Measure execution time for No Elimination
time_no_elim = timeit.timeit(lambda: evaluate_model(X_train, X_test, y_train, y_test), number=10)

# Measure execution time for RFE
time_rfe = timeit.timeit(lambda: evaluate_model(X_train_rfe, X_test_rfe, y_train_rfe, y_test_rfe), number=10)

# Measure execution time for LDA
time_lda = timeit.timeit(lambda: evaluate_model(X_train_lda, X_test_lda, y_train_lda, y_test_lda), number=10)

# Measure execution time for PCA
time_pca = timeit.timeit(lambda: evaluate_model(X_train_pca, X_test_pca, y_train_pca, y_test_pca), number=10)

# Plot comparison bar chart
plt.figure(figsize=(14, 7))

# Bar chart for MSE
plt.subplot(1, 3, 1)
methods = ['No Elimination', 'RFE', 'LDA', 'PCA']
mse_values = [mse_no_elim, mse_rfe, mse_lda, mse_pca]
plt.bar(methods, mse_values, color=['blue', 'orange', 'green', 'red'])
plt.xlabel('Feature Selection Method')
plt.ylabel('Mean Squared Error (MSE)')
plt.title('MSE Comparison')

# Bar chart for R²
plt.subplot(1, 3, 2)
r2_values = [r2_no_elim, r2_rfe, r2_lda, r2_pca]
plt.bar(methods, r2_values, color=['blue', 'orange', 'green', 'red'])
plt.xlabel('Feature Selection Method')
plt.ylabel('R-squared (R²)')
plt.title('R² Comparison')

# Bar chart for execution time
plt.subplot(1, 3, 3)
time_values = [time_no_elim, time_rfe, time_lda, time_pca]
plt.bar(methods, time_values, color=['blue', 'orange', 'green', 'red'])
plt.xlabel('Feature Selection Method')
plt.ylabel('Execution Time (seconds)')
plt.title('Execution Time Comparison')

plt.tight_layout()
plt.show()
