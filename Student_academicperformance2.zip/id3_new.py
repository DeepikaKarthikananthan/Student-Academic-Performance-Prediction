import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.preprocessing import LabelEncoder
import seaborn as sns
import numpy as np

# Load the dataset
file_path = 'Final_Student_Dataset.csv'
dataset = pd.read_csv(file_path)

# Drop unnecessary columns
dataset = dataset.drop(columns=['Roll No.', 'Name'])

# Encode categorical variables
label_encoders = {}
for column in ['Gender', 'Branch', 'Course']:
    le = LabelEncoder()
    dataset[column] = le.fit_transform(dataset[column])
    label_encoders[column] = le

# Define features and target
X = dataset.drop(columns=['CGPA'])
y = dataset['CGPA']

# Convert the target variable to binary for classification (e.g., CGPA >= 7.5 as 1, else 0)
threshold = 7.5
y_binary = np.where(y >= threshold, 1, 0)

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y_binary, test_size=0.2, random_state=42)

# Initialize and train the Decision Tree model with 'entropy' criterion for ID3
dt_model = DecisionTreeClassifier(criterion='entropy', random_state=42)
dt_model.fit(X_train, y_train)

# Predict on the test set
y_pred = dt_model.predict(X_test)

# Evaluate the model
accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred)
recall = recall_score(y_test, y_pred)
f1 = f1_score(y_test, y_pred)

# Display the results
print(f"Accuracy: {accuracy}")
print(f"Precision: {precision}")
print(f"Recall: {recall}")
print(f"F1 Score: {f1}")



# Plot actual vs predicted values
plt.figure(figsize=(10, 6))
plt.bar(range(len(y_test)), y_test, alpha=0.6, label='Actual', color='blue')
plt.bar(range(len(y_pred)), y_pred, alpha=0.6, label='Predicted', color='orange')
plt.xlabel('Sample Index')
plt.ylabel('Binary CGPA (>= 7.5)')
plt.title('Actual vs Predicted Values (ID3 Decision Tree)')
plt.legend()
plt.show()

# Visualize the Decision Tree
plt.figure(figsize=(20, 10))
plot_tree(dt_model, feature_names=X.columns, filled=True, rounded=True, fontsize=10)
plt.title('ID3 Decision Tree Visualization')
plt.show()
