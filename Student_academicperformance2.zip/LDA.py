import pandas as pd
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder

# Load the dataset
file_path = 'Student_academicperformance2.csv'
data = pd.read_csv(file_path)

# Clean the data
data_cleaned = data.drop(columns=['Roll No.', 'Name'])

# Encode categorical variables using one-hot encoding
data_encoded = pd.get_dummies(data_cleaned, drop_first=True)

# Separate features (X) and target (y)
X = data_encoded.drop(columns=['CGPA'])
y = data_encoded['CGPA']  

# Fill missing values with 0
X = X.fillna(0)

# Convert CGPA into discrete classes for LDA
# For simplicity, we'll create three bins: low, medium, high
y_class = pd.cut(y, bins=3, labels=['Low', 'Medium', 'High'])

# Initialize LDA
lda = LDA(n_components=2)  # Number of components is less than the number of classes

# Fit LDA and transform features
X_lda = lda.fit_transform(X, y_class)

# Initialize Linear Regression model
reg_model = LinearRegression()

# Split the dataset: 20% for training, 80% for testing
X_train, X_test, y_train, y_test = train_test_split(X_lda, y, test_size=0.8, random_state=42)

# Train the model
reg_model.fit(X_train, y_train)

# Predict on the test set
y_pred = reg_model.predict(X_test)

# Evaluate the model
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)
accuracy = r2 

# Display the selected features and model evaluation metrics
print("Number of components selected by LDA:", X_lda.shape[1])
print("Mean Squared Error (MSE):", mse)
print("R-squared (R²):", r2)
print("Accuracy (R²):", accuracy)

# Plot predicted vs. actual CGPA
plt.figure(figsize=(12, 6))

# Scatter plot of predicted vs. actual values
plt.subplot(1, 2, 1)
plt.scatter(y_test, y_pred, alpha=0.7)
plt.xlabel('Actual CGPA')
plt.ylabel('Predicted CGPA')
plt.title('Predicted vs Actual CGPA')

plt.tight_layout()
plt.show()
